<?php
$servername="localhost";
$username="root";
$password="";
$db="MyDB";

$conn=new mysqli($servername,$password,$db);

if($conn->connect_error){
    die("Connection failed".$conn->connect_error);
}
echo"Connected Successfully";
?>