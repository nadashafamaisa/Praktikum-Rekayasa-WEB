<?php
include 'koneksi.php';
$sql="INSERT INTO Tamu(nim, nama, jk, jurusan, tgl_lahir, email, foto, file_pdf)
VALUES('".$nim.",'".$nama."','".$_POST['rbjk']."','".$jur."','".$tgl_lahir."','".$email."','".$target_file_foto."','a')";
if($conn->query($sql)===TRUE){
    echo"New Record create Successfully";
}else{
    echo"Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>