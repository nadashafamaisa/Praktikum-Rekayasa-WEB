<?php
$var_char="Cah Ayu";
$int = 15;
$real=3.14;
$var_bool=true;
print("Contoh Tipe data String  : ".$var_char."<br>");
echo ("Contoh Tipe Data Integer : ".$int."<br>");
print("Contoh Tipe data Float   : ".$real."<br>");
echo  "Contoh Tipe Data Boolean : ".$var_bool."<br>";
?>