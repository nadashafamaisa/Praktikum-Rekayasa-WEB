<?php
print("Nama        : Nada Shafa Maisa<br>");
print("NIM         : 20030014<br>");
print("Prodi       : Informatika<br>");
print("Mata Kuliah : Praktikum Rekayasa Web Kelas D<br>");

$berat_badan = 43;
$tinggi_badan = 1.53;
$bmi = $berat_badan / ($tinggi_badan * $tinggi_badan);
$bmi = round($bmi, 1);

    echo "<br>Body Mass Index (BMI) Kamu adalah: ".$bmi."<br>";

    if($bmi < 18.5){
        echo "Kamu Kekurangan Berat Badan atau Terlalu Kurus.";
    }elseif($bmi >= 18.5 && $bmi <= 24.9){
        echo "Kamu Memiliki Berat Badan yang Sehat.";
    }elseif($bmi >= 25 && $bmi <= 29.9){
        echo "Kamu Kelebihan Berat Badan.";
    }else{
        echo "Kamu Obesitas.";
    }
?>